import 'package:flutter/material.dart';
import 'package:startup_namer/Homepage.dart';
import 'package:startup_namer/wordsList.dart';
import 'package:startup_namer/cardText.dart';

class TabBarDemo extends StatefulWidget {
  @override
  _TabBarDemoState createState() => _TabBarDemoState();
}

class _TabBarDemoState extends State<TabBarDemo> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: DefaultTabController(
        length: 4,
        child: Scaffold(
          appBar: AppBar(
            bottom: const TabBar(
              tabs: [
                Tab(icon: Icon(Icons.directions_car)),
                Tab(icon: Icon(Icons.directions_transit)),
                Tab(icon: Icon(Icons.directions_bike)),
                Tab(icon: Icon(Icons.ac_unit_rounded)),
              ],
            ),
            title: const Text(
              'Taste of India',
              style: TextStyle(fontSize: 30),
              textAlign: TextAlign.center,
            ),
          ),
          body: TabBarView(
            children: [
              Homepage(),
              cardText(),
              RandomWords(),
              Icon(Icons.directions_bike),
            ],
          ),
        ),
      ),
    );
  }
}
